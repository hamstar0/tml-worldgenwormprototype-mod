using System;
using System.Collections.Generic;
using Terraria;
using Terraria.World.Generation;


namespace WorldGenWormPrototype {
	public partial class WormGenPass : GenPass {
		public static WormNode CrystalCaveSnakeBehavior(
					IList<WormNode> nodes,
					int maxNodes,
					int originTileX,
					int originTileY ) {
			int radius;
			int minWidth = 4;
			int maxWidth = 24;

			if( nodes.Count <= 2 ) {
				radius = WorldGen.genRand.Next( (int)((float)maxWidth * 1.5f), maxWidth * 3 ); // start fat
				radius /= nodes.Count + 1;
			} else if( nodes.Count >= (maxNodes - 5) ) {
				float range = 6 - (maxNodes - nodes.Count);
				radius = (int)( (float)minWidth / (float)range );  // taper
			} else {
				radius = WorldGen.genRand.Next( minWidth, maxWidth );
			}

			if( nodes.Count == 0 ) {
				return new WormNode { TileX = originTileX, TileY = originTileY, Radius = radius };
			}

			return WormGenPass.CreateNextCrystaCaveNode( nodes, radius );
		}


		////////////////

		private static WormNode CreateNextCrystaCaveNode( IList<WormNode> nodes, int radius ) {
			int tests = 14;
			int tilePadding = 6;
			WormNode currNode = nodes[ nodes.Count - 1 ];

			var testNodes = new List<WormNode>( tests );
			for( int i = 0; i < tests; i++ ) {
				WormNode testNode = WormGenPass.CreateTestNode( currNode, radius );
				testNodes.Add( testNode );
			}

			WormNode bestNode = null;
			float prevGauged = -1f;
			foreach( WormNode testNode in testNodes ) {
				float gauged = WormGenPass.GaugeCrystalCaveNode( testNode, nodes, tilePadding );
				if( prevGauged != -1 && gauged > prevGauged ) { continue; }

				prevGauged = gauged;
				bestNode = testNode;
			}

			return bestNode;
		}


		////////////////

		private static float GaugeCrystalCaveNode( WormNode node, IList<WormNode> nodes, float tilePadding ) {
			float gauged = 0f;

			foreach( WormNode existingNode in nodes ) {
				float value = (float)existingNode.GetDistance( node );

				value -= existingNode.Radius + node.Radius + tilePadding;
				if( value < 0f ) {
					value = 100000 - value;
				}

				gauged += value;
			}

			return gauged / (float)nodes.Count;
		}
	}
}