using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.World.Generation;


namespace WorldGenWormPrototype {
	public partial class WormGenPass : GenPass {
		public static WormNode CreateTestNode( WormNode prevNode, int radius ) {
			float randDir = WorldGen.genRand.NextFloat() * (float)Math.PI * 2f;
			double dist = radius + prevNode.Radius;
			double x = Math.Cos( randDir ) * dist;
			double y = Math.Sin( randDir ) * dist;

			return new WormNode {
				TileX = (int)x + prevNode.TileX,
				TileY = (int)y + prevNode.TileY,
				Radius = radius
			};
		}



		////////////////

		public void StartWorm(
					GenerationProgress progress,
					float thisProgress,
					int tileX,
					int tileY,
					int minNodes,
					int maxNodes,
					WormNodeGenerator generator ) {
			int pivotNodeCount = WorldGen.genRand.Next( minNodes, maxNodes );
			int currExpectedNodeCount = pivotNodeCount;
			var nodeList = new List<WormNode>();
			float progressUnit = (float)thisProgress / (float)pivotNodeCount;

			for( int i=0; i<pivotNodeCount; i++ ) {
				WormNode nextNode = generator( nodeList, currExpectedNodeCount, tileX, tileY );

				if( i >= 1 ) {
					WormNode prevNode = nodeList[ nodeList.Count - 1 ];
					IList<WormNode> interNodes = this.CreateInterpolatedNodes( prevNode, nextNode );
					foreach( WormNode interNode in interNodes ) {
						nodeList.Add( interNode );
						currExpectedNodeCount++;
					}
				}

				nodeList.Add( nextNode );

				progress.Value += progressUnit * 0.5f;
			}

			progressUnit = (float)thisProgress / (float)nodeList.Count;

			for( int i=0; i<nodeList.Count; i++ ) {
				this.CarveNode( nodeList[i] );

				progress.Value += progressUnit * 0.5f;
			}
		}


		////////////////
		
		public IList<WormNode> CreateInterpolatedNodes( WormNode prevNode, WormNode nextNode ) {
			double incIntervals = 2d;
			var nodes = new List<WormNode>();

			double xDist = nextNode.TileX - prevNode.TileX;
			double yDist = nextNode.TileY - prevNode.TileY;
			double dist = Math.Sqrt( (xDist*xDist) + (yDist*yDist) );

			if( dist < incIntervals ) {
				return nodes;
			}

			for( double i=incIntervals; i<dist; i+=incIntervals ) {
				double perc = i / dist;
				int x = prevNode.TileX + (int)(xDist * perc);
				int y = prevNode.TileY + (int)(yDist * perc);
				int rad = (int)MathHelper.Lerp( (float)prevNode.Radius, (float)nextNode.Radius, (float)perc );

				nodes.Add( new WormNode { TileX = x, TileY = y, Radius = rad } );
			}

			return nodes;
		}


		////////////////

		/*public void CarveNodePath( WormNode currNode, WormNode nextNode ) {
			float radius = currNode.Radius;
			float tileX = currNode.TileX;
			float tileY = currNode.TileY;

			float xDiff = nextNode.TileX - currNode.TileX;
			float yDiff = nextNode.TileY - currNode.TileY;
			float maxDist = (float)Math.Sqrt( (xDiff * xDiff) + (yDiff * yDiff) );
			if( maxDist < 1f ) { maxDist = 1f; }

			for( float i=1f; i<=maxDist; i+=1f ) {
				this.CarveNode( (int)tileX, (int)tileY, (int)radius );

				radius = MathHelper.Lerp( currNode.Radius, nextNode.Radius, (i/maxDist) );
				tileX += xDiff / maxDist;
				tileY += yDiff / maxDist;
			}
		}*/

		////

		public void CarveNode( WormNode node ) {
			int minX = node.TileX - node.Radius;
			int maxX = node.TileX + node.Radius;
			int minY = node.TileY - node.Radius;
			int maxY = node.TileY + node.Radius;
			int radSqr = node.Radius * node.Radius;

			for( int i=minX; i<maxX; i++ ) {
				for( int j=minY; j<maxY; j++ ) {
					int xDist = i - node.TileX;
					int yDist = j - node.TileY;
					int distSqr = (xDist * xDist) + (yDist * yDist);

					if( distSqr > radSqr ) {
						if( j >= node.TileY ) {
							break;
						} else {
							continue;
						}
					}

					if( i>=0 && i<Main.maxTilesX && j>=0 && j<Main.maxTilesY ) {
						Main.tile[i, j] = new Tile();
					}
				}
			}
		}
	}
}